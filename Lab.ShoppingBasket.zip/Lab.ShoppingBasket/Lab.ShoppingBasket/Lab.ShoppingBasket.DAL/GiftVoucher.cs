﻿namespace Lab.ShoppingBasket.DAL
{
    public class GiftVoucher
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public decimal Value { get; set; }
    }
}
