Getting started with Unity3.Wcf
-------------------------------

Find out how to use Unity.Wcf by visiting https://bitbucket.org/rolosoft/components-wcf-unityintegrator/

Please report all bugs and feature requests on BitBucket.