﻿
namespace Lab.ShoppingBasket.Utilities.Enumerations.Product
{
    public enum Category
    {
        Hats,
        GiftVoucher,
        HeadGear,
        Clothes
    }
}
