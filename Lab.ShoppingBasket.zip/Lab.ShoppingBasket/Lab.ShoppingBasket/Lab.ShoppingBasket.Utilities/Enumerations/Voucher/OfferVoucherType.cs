﻿
namespace Lab.ShoppingBasket.Utilities.Enumerations.Voucher
{
    public enum OfferVoucherType
    {
        Basket,
        Product
    }
}
