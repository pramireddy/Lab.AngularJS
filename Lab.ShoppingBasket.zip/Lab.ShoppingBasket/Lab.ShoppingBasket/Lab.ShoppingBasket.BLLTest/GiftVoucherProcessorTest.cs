﻿using NUnit.Framework;

namespace Lab.ShoppingBasket.BLLTest
{
    [TestFixture]
    public class GiftVoucherProcessorTest
    {
        // TOOD - add tests to check Basket Total after applying GiftVoucherProcessor
    }
}
