﻿using NUnit.Framework;

namespace Lab.ShoppingBasket.BLLTest
{
    [TestFixture]
    public class OfferVoucherProcessorTest
    {
        // TOOD - add tests to check Basket Total and Messages after applying OfferVocherProccessor
        // TO DO: Write tests like what we did for "Lab.ShoppingBasket.ServiceTest.BasketServiceTest"
    }
}
